# This dataset consists of Forbes's list of the world’s highest-earning athletes from 1990-2020.

# The Goal of this project is to clean the data, analyze it and then find who were the top 5 earners in this dataset

find dataset here: https://www.kaggle.com/datasets/parulpandey/forbes-highest-paid-athletes-19902019


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

import pandasql as ps
from pandasql import sqldf
```

# > Import Data


```python
data = pd.read_csv('forbes_atheletes.csv')
data = data.set_index('S.NO')
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Nationality</th>
      <th>Current Rank</th>
      <th>Previous Year Rank</th>
      <th>Sport</th>
      <th>Year</th>
      <th>earnings ($ million)</th>
    </tr>
    <tr>
      <th>S.NO</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Mike Tyson</td>
      <td>USA</td>
      <td>1</td>
      <td>NaN</td>
      <td>boxing</td>
      <td>1990</td>
      <td>28.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Buster Douglas</td>
      <td>USA</td>
      <td>2</td>
      <td>NaN</td>
      <td>boxing</td>
      <td>1990</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Sugar Ray Leonard</td>
      <td>USA</td>
      <td>3</td>
      <td>NaN</td>
      <td>boxing</td>
      <td>1990</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Ayrton Senna</td>
      <td>Brazil</td>
      <td>4</td>
      <td>NaN</td>
      <td>auto racing</td>
      <td>1990</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Alain Prost</td>
      <td>France</td>
      <td>5</td>
      <td>NaN</td>
      <td>auto racing</td>
      <td>1990</td>
      <td>9.0</td>
    </tr>
  </tbody>
</table>
</div>



## renaming earnings column for simplicity


```python
data.rename(columns={'earnings ($ million)': 'earnings'}, inplace=True)
```

# >Data Preparation


```python
data['Sport'].unique()
```




    array(['boxing', 'auto racing', 'golf', 'basketball', 'Basketball',
           'Boxing', 'Auto Racing', 'Golf', 'Tennis', 'NFL', 'Auto racing',
           'NBA', 'Baseball', 'Ice Hockey', 'American Football / Baseball',
           'tennis', 'ice hockey', 'F1 Motorsports', 'NASCAR', 'Hockey',
           'Auto Racing (Nascar)', 'F1 racing', 'American Football', 'soccer',
           'baseball', 'cycling', 'motorcycle gp', 'Soccer', 'MMA'],
          dtype=object)



## Some of the labels for the 'Sport' column are repeated. For example there is 'Ice Hockey', 'ice hockey' and 'Hockey'. This should be corrected. 

* Note: 'American Football / Baseball' is being grouped with 'NFL' because the only name associated with 'American Football / Baseball' is 'Deion Sanders' who was a football player

* Note: All car racing categories are being grouped together as 'Auto Racing'


```python
data = data.replace(to_replace = 'boxing', value = 'Boxing')
data = data.replace(to_replace = ['auto racing','Auto racing','Auto Racing (Nascar)','NASCAR','F1 Motorsports','F1 racing'], value = 'Auto Racing')
data = data.replace(to_replace = 'golf', value = 'Golf')
data = data.replace(to_replace = ['basketball','Basketball'], value = 'NBA')
data = data.replace(to_replace = 'tennis', value = 'Tennis')
data = data.replace(to_replace = ['ice hockey','Hockey'], value = 'Ice Hockey')
data = data.replace(to_replace = ['American Football', 'American Football / Baseball'], value = 'NFL')
data = data.replace(to_replace = 'soccer', value = 'Soccer')
data = data.replace(to_replace = 'baseball', value = 'Baseball')
```

##  We need to correct having two names ('Aaron Rodgers', 'Aaron Rogers', 'Shaq O'Neal', 'Shaquille O'Neal') repeated.


```python
a = data['Name'].unique()
print(sorted(a))
```

    ['Aaron Rodgers', 'Aaron Rogers', 'Alain Prost', 'Alex Rodriguez', 'Andre Agassi', 'Andrew Luck', 'Arnold Palmer', 'Ayrton Senna', 'Buster Douglas', 'Cam Newton', 'Canelo Alvarez', 'Carson Wentz', 'Cecil Fielder', 'Conor McGregor', 'Cristiano Ronaldo', 'Dale Earnhardt', 'Dale Earnhardt Jr.', 'David Beckham', 'Deion Sanders', 'Dennis Rodman', 'Donovan "Razor" Ruddock', 'Drew Brees', 'Eli Manning', 'Emmit Smith', 'Evander Holyfield', 'Floyd Mayweather', 'Gary Sheffield', 'George Foreman', 'Gerhard Berger', 'Grant Hill', 'Greg Norman', 'Jack Nicklaus', 'Jacques Villeneuve', 'James Harden', 'Jeff Gordon', 'Jim Courier', 'Joe Montana', 'Joe Sakic', 'Jordan Spieth', 'Kevin Durant', 'Kevin Garnett', 'Kimi Raikkonen', 'Kirk Cousins', 'Kobe Bryant', 'Lance Armstrong', 'LeBron James', 'Lennox Lewis', 'Lewis Hamilton', 'Lionel Messi', 'Manny Pacquiao', 'Matt Ryan', 'Matthew Stafford', 'Michael Jordan', 'Michael Moorer', 'Michael Schumacher', 'Michael Vick', 'Mike Tyson', 'Monica Seles', 'Muhammad Ali', 'Neymar', 'Nigel Mansell', 'Novak Djokovic', 'Oscar De La Hoya', 'Patrick Ewing', 'Peyton Manning', 'Phil Mickelson', 'Rafael Nadal', 'Riddick Bowe', 'Roger Federer', 'Ronaldinho', 'Rory McIlroy', 'Russell Wilson', 'Sergei Federov', "Shaq O'Neal", "Shaquille O'Neal", 'Stephen Curry', 'Sugar Ray Leonard', 'Terrell Suggs', 'Tiger Woods', 'Tom Brady', 'Valentino Rossi', 'Wayne Gretzky']
    


```python
data = data.replace(to_replace = "Aaron Rogers", value = "Aaron Rodgers")
data = data.replace(to_replace = "Shaq O'Neal", value = "Shaquille O'Neal")
```

## There are 24 missing values in the 'Previous Year Rank' column. This is not a problem because it isn't being considered. 


```python
data.isna().sum()
```




    Name                   0
    Nationality            0
    Current Rank           0
    Previous Year Rank    24
    Sport                  0
    Year                   0
    earnings               0
    dtype: int64



## The shape of the dataset is 301x7


```python
data.shape
```




    (301, 7)



## Although the dataset is 301x7, there are only 80 unique names in the dataset. In 2015 Floyd Mayweather made  300 million, and in 2018 he made 285 million. This is worth considering while looking at the data. We are looking at highest reported earnings per year, and many of the reports are from the same people. Below is a list of the top 10 reported years.


```python
n = len(pd.unique(data['Name']))
  
print("Number of Unique Names :", 
      n)
```

    Number of Unique Names : 80
    


```python
query = "SELECT Sport, Name, earnings, Year \
         FROM data \
         ORDER BY earnings DESC\
         LIMIT 10"

df = sqldf(query)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sport</th>
      <th>Name</th>
      <th>earnings</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Boxing</td>
      <td>Floyd Mayweather</td>
      <td>300.0</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Boxing</td>
      <td>Floyd Mayweather</td>
      <td>285.0</td>
      <td>2018</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Boxing</td>
      <td>Manny Pacquiao</td>
      <td>160.0</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Soccer</td>
      <td>Lionel Messi</td>
      <td>127.0</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Golf</td>
      <td>Tiger Woods</td>
      <td>115.0</td>
      <td>2008</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Soccer</td>
      <td>Lionel Messi</td>
      <td>111.0</td>
      <td>2018</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Golf</td>
      <td>Tiger Woods</td>
      <td>110.0</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Soccer</td>
      <td>Cristiano Ronaldo</td>
      <td>109.0</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Soccer</td>
      <td>Cristiano Ronaldo</td>
      <td>108.0</td>
      <td>2018</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Tennis</td>
      <td>Roger Federer</td>
      <td>106.3</td>
      <td>2020</td>
    </tr>
  </tbody>
</table>
</div>



# > Analysis

## We see that most of these reported earnings come from NBA players, and then boxers, and so on.


```python
sns.set(rc={'figure.figsize':(15,10)})
df = data.groupby('Sport')['Sport'].count().sort_values()
df.plot(kind='barh')
plt.xlabel('Count')
plt.show()
```


    
![png](output_24_0.png)
    


## The min and max of earnings(in millions of dollars) are 8.1 and 300 respectively


```python
print(min(data['earnings']))
print(max(data['earnings']))
```

    8.1
    300.0
    

## Here is a box plot of the highest-earners by sport. Ignoring the MMA athelete of whom there is only one, we see the soccer players have the highest median, highest upper quartile and highest max (that is not an outlier). Boxers have the absolute highest reported earnings (these are the outliers represented as diamonds). 

## Also in this plot, we can observe the interquartile range. For example, the IQR for tennis players is much greater than it is for NFL players.


```python
ax = sns.boxplot(x = data['Sport'], y = data['earnings'])
ax.set_xticklabels(ax.get_xticklabels(),rotation=50)
plt.show()
```


    
![png](output_28_0.png)
    


## The outliers in boxing are Floyd Mayweather and Manny Pacquiao


```python
query = "SELECT Name, earnings, Year \
         FROM data \
         WHERE Sport = 'Boxing' \
         ORDER BY earnings DESC\
         LIMIT 4"

df = sqldf(query)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>earnings</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Floyd Mayweather</td>
      <td>300.0</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Floyd Mayweather</td>
      <td>285.0</td>
      <td>2018</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Manny Pacquiao</td>
      <td>160.0</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Floyd Mayweather</td>
      <td>105.0</td>
      <td>2014</td>
    </tr>
  </tbody>
</table>
</div>



# > Of these exceptional earnings reports, who ranks top 5 from 1990-2020? To find this we will need to sum the earnings of every year by name.

## Here is a list of the top 10 with the highest earner being Tiger Woods, and then LeBron James and so on.


```python
data.groupby(by='Name')['earnings'].sum().sort_values(ascending=False).head(10)
```




    Name
    Tiger Woods           1373.8
    LeBron James           844.8
    Floyd Mayweather       840.0
    Cristiano Ronaldo      787.1
    Roger Federer          781.1
    Michael Jordan         738.8
    Lionel Messi           715.5
    Michael Schumacher     639.0
    Kobe Bryant            601.1
    Phil Mickelson         519.9
    Name: earnings, dtype: float64



## However, some of these earnings go as far back as 1990. If we adjust for inflation and list the sum of their earnerning in terms of 2020 , the top 5 looks like this: Tiger woods at 1.732 billion, Michael Jordan at 1.126 billion, LeBron James at 916.62 million and so on.


```python
Name = ['Tiger Woods','Michael Jordan','LeBron James','Michael Schumacher','Floyd Mayweather']
Earnings = [1732,1126.27,916.62,910.5,909.08]
Sport = ['Golf','Basketball','Basketball','Auto Racing','Boxing']
df = pd.DataFrame({'Name':Name,'Sport':Sport,'Sum of Earnings(adjusted)':Earnings})
df.index = np.arange(1, len(df) + 1)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Sport</th>
      <th>Sum of Earnings(adjusted)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Tiger Woods</td>
      <td>Golf</td>
      <td>1732.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Michael Jordan</td>
      <td>Basketball</td>
      <td>1126.27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LeBron James</td>
      <td>Basketball</td>
      <td>916.62</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Michael Schumacher</td>
      <td>Auto Racing</td>
      <td>910.50</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Floyd Mayweather</td>
      <td>Boxing</td>
      <td>909.08</td>
    </tr>
  </tbody>
</table>
</div>



## The method of adjusting for inflation was using an inflation calculator found on the American Instistute for Economic Research's website. In 1997 Tiger Woods earned 26.1 million dollars which in 2020-money would be worth 42.09 million. These figures were done for each year of these reports for each athelete. When who to consider for the top 5(adjusted), only the top 10(non-adjusted) were considered because after Phil Mickelson, the sum of earnings dropped off drastically, and inflation would not have been enough to place someone who ranked under Phil Mickelson into the top 5(adjusted).

## Screenshots of the earnings adjustments is placed below and the calculator can be found with this url.

https://www.aier.org/cost-of-living-calculator/?utm_source=Google%20Ads&utm_medium=Google%20CPC&utm_campaign=COLA&gclid=CjwKCAjwpayjBhAnEiwA-7ena_AEqyF9Dijbc26FA52RkW4sJIIv_bSzyD058FYTv06x1fYn_vGtmRoCk40QAvD_BwE

![Screenshot%20%28546%29.png](attachment:Screenshot%20%28546%29.png)

![Screenshot%20%28547%29.png](attachment:Screenshot%20%28547%29.png)

![Screenshot%20%28548%29.png](attachment:Screenshot%20%28548%29.png)

# Thank you for reading!


```python

```
